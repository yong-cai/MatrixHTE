library(readstata13)
vil_outcomes <- read.dta13("../Data/Outcomes/VillageLevelOutcomes_RFA_bss.dta")

# Generate pre-treatment outcome and sort
vil_outcomes_pre <- vil_outcomes[vil_outcomes$t==1, c(1,3,4:9)]
vil_outcomes_pre <- vil_outcomes_pre[order(vil_outcomes_pre$village), ]
n <- dim(vil_outcomes_pre)[1]

# Normalize variables by SD, so that variables are of comparable magnitudes
for(col in 3:8){
  vil_outcomes_pre[, col] <- vil_outcomes_pre[, col]/sd(vil_outcomes_pre[, col])
}

# Compute distance between each village
distance <- dist(vil_outcomes_pre[, c(3,5:8)])
distance.mat <- matrix(0, n, n)
distance.mat[lower.tri(distance.mat)] <- distance
distance.mat <- distance.mat+ t(distance.mat)

vil.index <- vil_outcomes_pre$village
treat.index <- vil_outcomes_pre$village[vil_outcomes_pre$MFVillage==1]
control.index <- vil_outcomes_pre$village[vil_outcomes_pre$MFVillage==0]

best_control_val <- apply(distance.mat[, c(1:n)[vil_outcomes_pre$MFVillage==0]], 1, min)
best_control_ind <- apply(distance.mat[, c(1:n)[vil_outcomes_pre$MFVillage==0]], 1, function(x) control.index[which.min(x)])

vil_outcomes_pre <- vil_outcomes[vil_outcomes$t==1, c(1,3,4:9)]
vil_outcomes_pre <- vil_outcomes_pre[order(vil_outcomes_pre$village), ]

# Dataframe containing best matches. Subset to treated villages (MFVillage = 1)
# and the pair with the best match (lowest best_control_val) is 57 and 44. 
vil_dist <- cbind(vil_outcomes_pre[, 1:2], best_control_ind, best_control_val, vil_outcomes_pre[, 3:8])

save(vil_dist, file = "vil_dist.Rdata")

