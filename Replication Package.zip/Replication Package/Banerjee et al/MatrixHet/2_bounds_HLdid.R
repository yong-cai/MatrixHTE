library(readstata13)
library(MatrixHTE)

village_outcomes = read.dta13("../Data/Outcomes/VillageLevelOutcomes_RFA_bss.dta")
village_outcomes_pre <- village_outcomes[village_outcomes$t == 1, ]

link_outcomes = read.dta13("../Data/Outcomes/LinkLevelOutcomes_RFA_bss.dta",
                           select.cols = c("hhid_i","hhid_j","A_ij_1","A_ij_2"))

# Build adjacency matrices
# Row and column of adjacency matrix corresponds hhid in link_outcomes
for(vilno in 1:77){
  if(vilno %in% c(13,22)){
    next
  }
  
  edges <- link_outcomes[link_outcomes$hhid_i > vilno*1000 & link_outcomes$hhid_i < (vilno+1)*1000,]
  
  # Set matrix size; not too different from N_pre_all in village_outcomes
  vil_n <- max(village_outcomes_pre$N_pre_all[village_outcomes_pre$village == vilno],
               max(edges$hhid_i)-vilno*1000, 
               max(edges$hhid_j)-vilno*1000)

  
  adj_1 <- matrix(0, vil_n, vil_n)
  adj_2 <- matrix(0, vil_n, vil_n)
  
  for(i in 1:dim(edges)[1]){
    row_index <- edges$hhid_i[i] - vilno*1000
    col_index <- edges$hhid_j[i] - vilno*1000

    adj_1[row_index, col_index] <- edges$A_ij_1[i]
    adj_2[row_index, col_index] <- edges$A_ij_2[i]

  }
  
  adj_1 <- adj_1 + t(adj_1)
  adj_2 <- adj_2 + t(adj_2)
  
  save(adj_1, adj_2, file = paste0("../AdjMat/vil_", vilno, "_balnet.Rdata"))

  print(vilno)
}

# Load random forest predictions
takeup_predictions = as.data.frame(read.csv(file = "../Data/Output/H_prediction_RF_cutoff_0.15.csv"))   
colnames(takeup_predictions) = c("","hhid","high","training_data")
takeup_predictions=takeup_predictions[,c("hhid","high")] # hhid in takeup_predictions is hhid in link_outcomes, see 00c_build_degrees.R 

# Load node outcomes, code taken from 01A_summary_stats.R
# new_hhid corresponds to the row and columns in adjacency matrices
node_outcomes = read.dta13("../Data/Outcomes/NodeLevelOutcomes_RFA_bss.dta")
node_outcomes$new_hhid = 1000*node_outcomes$village + node_outcomes$hhid
node_panel = read.dta13("../Data/Outcomes/NodeLevelPanel_RFA_bss.dta")
data  = merge(node_outcomes,node_panel,by.x = "new_hhid",by.y="hhid") 
data = merge(data, takeup_predictions,by.x = "new_hhid",by.y="hhid")

# Balance the data
balanced_hh <- unique(intersect(data$new_hhid[data$t == 1], data$new_hhid[data$t == 2]))
data$is_balanced <- data$new_hhid%in%balanced_hh


# Load Matchings 
load("vil_dist.Rdata")
vil_dist_treat <- vil_dist[vil_dist$MFVillage == 1, ]

ATE_combined <- matrix(0, 43, 4)

# Only computing bounds for best match. Set index to c(1:43) to compute bounds for all matches
index <- c(31)
for(i in index){
  treatvil <- vil_dist_treat$village[i]
  controlvil <- vil_dist_treat$best_control_ind[i]
  
  # Load adjacencies
  load(paste0("../AdjMat/vil_",treatvil,"_balnet.Rdata"))
  treat_pre <- adj_1
  treat_post <- adj_2
  load(paste0("../AdjMat/vil_",controlvil,"_balnet.Rdata"))
  control_pre <- adj_1
  control_post <- adj_2
  
  
  ##  Full bounds --------------------------------------------------------------
  treat <- treat_post - treat_pre
  control <- control_post - control_pre

  ATE <- mean(treat) - mean(control)
  
  disruption.full.hc <- array(0, c(3,3,6)) # output is such that [,,1] is full lower bound
  for(y1 in c(-1,0,1)){
    for(y0 in c(-1,0,1)){
      bounds <- dpo_bounds_svt_bin_did(treat_pre, treat_post, 
                                            control_pre, control_post,
                                            y1, y0, hc = TRUE)
      disruption.full.hc[y1+2, y0+2,] <- c(bounds$bounds, bounds$breakdown[1,], bounds$breakdown[2,])
    }
  }
  
  # HH bounds  -----------------------------------------------------------------
  treat.typeselector <- data$new_hhid[data$village.x == treatvil & data$t == 1 & data$is_balanced == T & data$high == 1]
  treat.typeselector <- treat.typeselector - treatvil*1000
  control.typeselector <- data$new_hhid[data$village.x == controlvil & data$t == 1 & data$is_balanced == T & data$high == 1]
  control.typeselector <- control.typeselector - controlvil*1000
  
  treat.typeselector <- treat.typeselector[treat.typeselector <= dim(treat_post)[1]]
  control.typeselector <- control.typeselector[control.typeselector <= dim(control_post)[1]]
  
  treat <- treat_post[treat.typeselector, treat.typeselector]-treat_pre[treat.typeselector, treat.typeselector]
  control <- control_post[control.typeselector,control.typeselector]-control_pre[control.typeselector,control.typeselector]

  ATE.hh <- mean(treat) - mean(control)

  disruption.hh.hc <- array(0, c(3,3,6))
  for(y1 in c(-1,0,1)){
    for(y0 in c(-1,0,1)){
      bounds <- dpo_bounds_svt_bin_did(treat_pre[treat.typeselector,treat.typeselector], treat_post[treat.typeselector,treat.typeselector], 
                                       control_pre[control.typeselector,control.typeselector], control_post[control.typeselector,control.typeselector],
                                       y1, y0, hc = TRUE)
      disruption.hh.hc[y1+2, y0+2,] <- c(bounds$bounds, bounds$breakdown[1,], bounds$breakdown[2,])
    }
  }
  
  # LL bounds  -----------------------------------------------------------------
  treat.typeselector <- data$new_hhid[data$village.x == treatvil & data$t == 1 & data$is_balanced == T & data$high == 0]
  treat.typeselector <- treat.typeselector - treatvil*1000
  control.typeselector <- data$new_hhid[data$village.x == controlvil & data$t == 1 & data$is_balanced == T & data$high == 0]
  control.typeselector <- control.typeselector - controlvil*1000
  
  treat.typeselector <- treat.typeselector[treat.typeselector <= dim(treat_post)[1]]
  control.typeselector <- control.typeselector[control.typeselector <= dim(control_post)[1]]
  
  treat <- treat_post[treat.typeselector, treat.typeselector]-treat_pre[treat.typeselector, treat.typeselector]
  control <- control_post[control.typeselector,control.typeselector]-control_pre[control.typeselector,control.typeselector]
  
  ATE.ll <- mean(treat) - mean(control)
  
  disruption.ll.hc <- array(0, c(3,3,6))
  for(y1 in c(-1,0,1)){
    for(y0 in c(-1,0,1)){
      bounds <- dpo_bounds_svt_bin_did(treat_pre[treat.typeselector,treat.typeselector], treat_post[treat.typeselector,treat.typeselector], 
                                       control_pre[control.typeselector,control.typeselector], control_post[control.typeselector,control.typeselector],
                                       y1, y0, hc = TRUE)
      disruption.ll.hc[y1+2, y0+2,] <- c(bounds$bounds, bounds$breakdown[1,], bounds$breakdown[2,])
    }
  }  
  
  # HL bounds  -----------------------------------------------------------------
  treat.typeselector.h <- data$new_hhid[data$village.x == treatvil & data$t == 1 & data$is_balanced == T & data$high == 1]
  treat.typeselector.h <- treat.typeselector.h - treatvil*1000
  treat.typeselector.l <- data$new_hhid[data$village.x == treatvil & data$t == 1 & data$is_balanced == T & data$high == 0]
  treat.typeselector.l <- treat.typeselector.l - treatvil*1000
  
  control.typeselector.h <- data$new_hhid[data$village.x == controlvil & data$t == 1 & data$is_balanced == T & data$high == 1]
  control.typeselector.h <- control.typeselector.h - controlvil*1000
  control.typeselector.l <- data$new_hhid[data$village.x == controlvil & data$t == 1 & data$is_balanced == T & data$high == 0]
  control.typeselector.l <- control.typeselector.l - controlvil*1000
  
  treat.typeselector.h <- treat.typeselector.h[treat.typeselector.h <= dim(treat_post)[1]]
  treat.typeselector.l <- treat.typeselector.l[treat.typeselector.l <= dim(treat_post)[2]] # technically can be dim(treat_full)[1]
  
  control.typeselector.h <- control.typeselector.h[control.typeselector.h <= dim(control_post)[1]]
  control.typeselector.l <- control.typeselector.l[control.typeselector.l <= dim(control_post)[2]]
  
  ATE.hl <- mean(treat_post[treat.typeselector.h,treat.typeselector.l]-treat_pre[treat.typeselector.h,treat.typeselector.l]) -
    mean(control_post[control.typeselector.h,control.typeselector.l]-control_pre[control.typeselector.h,control.typeselector.l]) 
  
  disruption.hl.hc <- array(0, c(3,3,6))
  for(y1 in c(-1,0,1)){
    for(y0 in c(-1,0,1)){
      bounds <- dpo_bounds_svt_bin_did(treat_pre[treat.typeselector.h,treat.typeselector.l], treat_post[treat.typeselector.h,treat.typeselector.l], 
                                       control_pre[control.typeselector.h,control.typeselector.l], control_post[control.typeselector.h,control.typeselector.l],
                                       y1, y0, hc = TRUE)
      disruption.hl.hc[y1+2, y0+2,] <- c(bounds$bounds, bounds$breakdown[1,], bounds$breakdown[2,])
    }
  }
  
  out.index <- c(treatvil, controlvil)

  save(disruption.full.hc, disruption.hh.hc,
       disruption.ll.hc, disruption.hl.hc, out.index, file = paste0("../did_bounds/vil_", i, ".Rdata"))
  
  ATE_combined[i,] <- c(ATE, ATE.hh, ATE.ll, ATE.hl)
  
  print(i)
}

colnames(ATE_combined) <- c("Full", "HH", "LL", "HL")
write.csv(cbind(vil_dist_treat[index, c(1,3)], ATE_combined[index, , drop = FALSE]), file = "../did_bounds/ATE.csv", row.names = F)

# Best Match
load(paste0("../did_bounds/vil_", 31, ".Rdata"))

full.bounds.hc <- cbind(disruption.full.hc[,1,1], disruption.full.hc[,1,2],
      disruption.full.hc[,2,1], disruption.full.hc[,2,2],
      disruption.full.hc[,3,1], disruption.full.hc[,3,2])

hh.bounds.hc <- cbind(disruption.hh.hc[,1,1], disruption.hh.hc[,1,2],
                      disruption.hh.hc[,2,1], disruption.hh.hc[,2,2],
                      disruption.hh.hc[,3,1], disruption.hh.hc[,3,2])

ll.bounds.hc <- cbind(disruption.ll.hc[,1,1], disruption.ll.hc[,1,2],
                      disruption.ll.hc[,2,1], disruption.ll.hc[,2,2],
                      disruption.ll.hc[,3,1], disruption.ll.hc[,3,2])

hl.bounds.hc <- cbind(disruption.hl.hc[,1,1], disruption.hl.hc[,1,2],
                      disruption.hl.hc[,2,1], disruption.hl.hc[,2,2],
                      disruption.hl.hc[,3,1], disruption.hl.hc[,3,2])

bounds.hc <- rbind(full.bounds.hc, hh.bounds.hc, ll.bounds.hc, hl.bounds.hc)

write.csv(bounds.hc, file = "../did_bounds/bestmatch_overall_bounds_hc.csv")
