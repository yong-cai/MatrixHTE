## =============================================================================
## STE & CATE for Villages 57 and 44                     
## =============================================================================
library("tidyverse")
library("MatrixHTE")
library("readstata13")

# ------------------------------------------------------------------------------
# Load Data                            
# ------------------------------------------------------------------------------

# Load node outcomes, code taken from 01A_summary_stats.R
# new_hhid corresponds to the row and columns in adjacency matrices
node_outcomes = read.dta13("../Data/Outcomes/NodeLevelOutcomes_RFA_bss.dta")
node_outcomes$new_hhid = 1000*node_outcomes$village + node_outcomes$hhid
node_panel = read.dta13("../Data/Outcomes/NodeLevelPanel_RFA_bss.dta")
data  = merge(node_outcomes,node_panel,by.x = "new_hhid",by.y="hhid") 
#data = merge(data, takeup_predictions,by.x = "new_hhid",by.y="hhid")

data.use <- data %>% filter(village.x %in% c(57,44) & t == 1)


# View(data.frame(colnames(data)))
# Stratify on HH size, top censor at 7
data.use$hhsize.x[data.use$hhsize.x > 7] <- 7
data.use$bed_no.x[data.use$bed_no.x > 2] <- 2
data.use$stratvar <- data.use$bed_no.x*7 + data.use$hhsize.x

data.treat <- data.use %>% filter(village.x %in% c(57) & t == 1)
data.control <- data.use %>% filter(village.x %in% c(44) & t == 1)

# table(data.treat$hhsize.x, data.treat$bed_no.x)
# table(data.control$hhsize.x, data.control$bed_no.x)

treatvil <- 57
controlvil <- 44

# Load adjacencies
load(paste0("../AdjMat/vil_",treatvil,"_balnet.Rdata"))
treat_pre <- adj_1
treat_post <- adj_2
load(paste0("../AdjMat/vil_",controlvil,"_balnet.Rdata"))
control_pre <- adj_1
control_post <- adj_2
treat.use <- treat_post - treat_pre
control.use <- control_post - control_pre

att_combined <- c()
for(treat.hh in 1:21){
  for(control.hh in 1:21){
    treat.id <- data.treat$new_hhid[data.treat$stratvar == treat.hh] - treatvil*1000
    control.id <- data.control$new_hhid[data.control$stratvar == control.hh] - controlvil*1000
    
    if(length(treat.id) == 0 || length(control.id) == 0){
      next
    }
    
    ATT <- mean(treat.use[treat.id, treat.id]) - mean(control.use[control.id, control.id])
    att_combined <- c(att_combined, rep(ATT, length(treat.id)))
  }
}


stt_combined <- ste(svt.smooth(treat.use, mean(treat.use), 0.01), 
                    svt.smooth(control.use, mean(control.use), 0.01), hc= TRUE)$stt

stt_combined <- data.frame(val = stt_combined)
att_combined <- data.frame(val = att_combined)

stt_combined$var <- "STT"
att_combined$var <- "CATT"

effect.mat <- rbind(stt_combined, att_combined)

ggplot(effect.mat, aes(x=val, fill = var)) +
  xlab(expr(paste("Effect")))+ylab("Density")+
  ggtitle(expr(paste("Distribution of Treatment Effects")))+
  geom_density(alpha = 0.6, adjust = 1)+
  scale_fill_manual(values=c("#56B4E9", "#F37735"))+
  labs(fill="") +
  #geom_histogram(alpha = 0.8, position = "identity", bins=100)+
  theme_minimal()+ #xlim(-0.3,0.3)+
  theme(plot.title = element_text(hjust = 0.5))

ggsave("../did_bounds/bestmatch_stt_catt.png", width = 15, height = 8, units = "cm")


