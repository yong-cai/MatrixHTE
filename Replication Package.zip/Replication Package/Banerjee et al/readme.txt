1) Download the replication file for Banerjee et al (2023) from <https://zenodo.org/record/7706650>

2) Copy the <MatrixHet> folder into the <Karnatake> subfolder. All R scripts in the MatrixHet folder should be run with Matrixet as the working directory. 

3) Run <1_matching.R> to find the best control village for each treatment village. 

4) Run <2_bounds_HLdid.R> to compute bounds for subgroups (Table 1)

5) Run <3_stt_catt.R> to compute STT and CATT (Figure 3)