for(year in 82:90){
  rawdata <- readLines(paste0("data/Haile Data/usfs",year,"/usfs", year))
  
  data <- data.frame(substr(rawdata, 1, 2))
  colnames(data) <- "region"
  data$forest <- substr(rawdata, 3, 4)
  data$district <- substr(rawdata, 5, 6)
  data$sale.number <- substr(rawdata, 7, 9)
  data$fiscal.year <- substr(rawdata, 10, 11)
  data$quarter <- substr(rawdata, 12, 12)
  data$salenumber <- substr(rawdata, 7, 9)
  
  data$state <- substr(rawdata, 14, 15)
  data$county <- substr(rawdata, 16, 18)
  data$sale.name <- substr(rawdata, 19, 44)
  data$compartment <- substr(rawdata, 45, 48)
  data$acres <- as.numeric(substr(rawdata, 49, 55))
  data$legal.description <- substr(rawdata, 56, 80)
  
  data$bid.date.month <- substr(rawdata, 85, 86)
  data$bid.date.day <- substr(rawdata, 87, 88)
  data$bid.date.year <- substr(rawdata, 89, 90)
  data$status <- substr(rawdata, 91, 91)
  data$sba.set.aside <- substr(rawdata, 92, 92)
  data$app.base.period <- substr(rawdata, 93, 95)
  data$zone <- substr(rawdata, 96, 96)
  data$salvage <- substr(rawdata, 97, 97)
  data$pricing.method <- substr(rawdata, 98, 98)
  data$pland.sab.col <- substr(rawdata, 99, 105)
  data$term.date.month <- substr(rawdata, 106, 107)
  data$term.date.day <- substr(rawdata, 108, 109)
  data$term.date.year <- substr(rawdata, 110, 111)
  data$contract.date.month <- substr(rawdata, 112, 113)
  data$contract.date.day <- substr(rawdata, 114, 115)
  data$contract.date.year <- substr(rawdata, 116, 117)
  data$contract.no <- substr(rawdata, 118, 128)
  data$contract.form.2400 <- substr(rawdata, 129, 130)
  data$contracting.officer <- substr(rawdata, 131, 131)
  data$method.of.sale <- substr(rawdata, 132, 132)
  data$reg.36cfr221 <- substr(rawdata, 133, 134)
  
  data$sale.size <- substr(rawdata, 153, 153)
  
  for(i in 0:13){
    data[[paste0("a.species.", i+1)]] <- substr(rawdata, 156 + i*65, 158 + i*65)
    data[[paste0("a.product.", i+1)]] <- substr(rawdata, 159 + i*65, 159 + i*65)
    data[[paste0("a.unit.", i+1)]] <- substr(rawdata, 160 + i*65, 160 + i*65)
    data[[paste0("a.stat.high.bid.", i+1)]] <- substr(rawdata, 161 + i*65, 166 + i*65)
    data[[paste0("a.1.high.bidder.", i+1)]] <- substr(rawdata, 167 + i*65, 172 + i*65)
    data[[paste0("a.2.high.bidder.", i+1)]] <- substr(rawdata, 173 + i*65, 178 + i*65)
    data[[paste0("a.3.high.bidder.", i+1)]] <- substr(rawdata, 179 + i*65, 184 + i*65)
    data[[paste0("a.4.high.bidder.", i+1)]] <- substr(rawdata, 185 + i*65, 190 + i*65)
    data[[paste0("a.5.high.bidder.", i+1)]] <- substr(rawdata, 191 + i*65, 196 + i*65)
    data[[paste0("a.6.high.bidder.", i+1)]] <- substr(rawdata, 197 + i*65, 202 + i*65)
    data[[paste0("a.7.high.bidder.", i+1)]] <- substr(rawdata, 203 + i*65, 208 + i*65)
    data[[paste0("a.8.high.bidder.", i+1)]] <- substr(rawdata, 209 + i*65, 214 + i*65)
    data[[paste0("a.9.high.bidder.", i+1)]] <- substr(rawdata, 215 + i*65, 220 + i*65)
  }
  print(paste0("Completed column ", 220 + i*65))
  
  
  for(i in 0:11){
    data[[paste0("b.rank.", i+1)]] <- substr(rawdata, 1066 + i*56, 1067 + i*56)
    data[[paste0("b.bidders.name.", i+1)]] <- substr(rawdata, 1068 + i*56, 1092 + i*56)
    data[[paste0("b.sba.class.", i+1)]] <- substr(rawdata, 1093 + i*56, 1093 + i*56)
    data[[paste0("b.identification.number.", i+1)]] <- substr(rawdata, 1094 + i*56, 1109 + i*56)
    data[[paste0("b.total.value.of.bid.", i+1)]] <- substr(rawdata, 1110 + i*56, 1121 + i*56)
  }
  print(paste0("Completed column ", 1121 + i*56))
  
  
  for(i in 0:1){
    data[[paste0("c.unit.of.measure.", i+1)]] <- substr(rawdata, 1740 + i*29, 1740 + i*29)
    data[[paste0("c.specified.road.construction.", i+1)]] <- substr(rawdata, 1741 + i*29, 1743 + i*29)
    data[[paste0("c.reconstruction.", i+1)]] <- substr(rawdata, 1744 + i*29, 1746 + i*29)
    data[[paste0("c.purchaser.credit.limit.", i+1)]] <- substr(rawdata, 1747 + i*29, 1753 + i*29)
    data[[paste0("c.temp.road.construction.", i+1)]] <- substr(rawdata, 1754 + i*29, 1756 + i*29)
    data[[paste0("c.haul.miles.", i+1)]] <- substr(rawdata, 1757 + i*29, 1759 + i*29)
    data[[paste0("c.temp.road.cost.", i+1)]] <- substr(rawdata, 1760 + i*29, 1766 + i*29)
    
  }
  print(paste0("Completed column ", 1766 + i*29))
  
  for(i in 0:13){
    data[[paste0("d.species.", i+1)]] <- substr(rawdata, 1796 + i*40, 1798 + i*40)
    data[[paste0("d.product.", i+1)]] <- substr(rawdata, 1799 + i*40, 1799 + i*40)
    data[[paste0("d.unit.", i+1)]] <- substr(rawdata, 1800 + i*40, 1800 + i*40)
    data[[paste0("d.volume.", i+1)]] <- substr(rawdata, 1801 + i*40, 1807 + i*40)
    data[[paste0("d.selling.value.", i+1)]] <- substr(rawdata, 1808 + i*40, 1813 + i*40)
    data[[paste0("d.logging.costs.", i+1)]] <- substr(rawdata, 1814 + i*40, 1818 + i*40)
    data[[paste0("d.mfg.cost.", i+1)]] <- substr(rawdata, 1819 + i*40, 1823 + i*40)
    data[[paste0("d.advertised.rate.", i+1)]] <- substr(rawdata, 1824 + i*40, 1829 + i*40)
    data[[paste0("d.appraised.net.rate.", i+1)]] <- substr(rawdata, 1830 + i*40, 1835 + i*40)
    
  }
  print(paste0("Completed column ", 1835 + i*40))
  
  
  for(i in c(0, -1)){
    data[[paste0("e.unit.of.measure.", 2+i)]] <- substr(rawdata, 2423 + i*65, 2423 + i*65)
    data[[paste0("e.volume.total.", 2+i)]] <- substr(rawdata, 2424 + i*65, 2430 + i*65)
    data[[paste0("e.falling.and.bucking.", 2+i)]] <- substr(rawdata, 2431 + i*65, 2435 + i*65)
    data[[paste0("e.skidding.and.loading.", 2+i)]] <- substr(rawdata, 2436 + i*65, 2440 + i*65)
    data[[paste0("e.stump.to.truck.", 2+i)]] <- substr(rawdata, 2441 + i*65, 2445 + i*65)
    data[[paste0("e.haul.amt.", 2+i)]] <- substr(rawdata, 2446 + i*65, 2449 + i*65)
    data[[paste0("e.road.maintenance", 2+i)]] <- substr(rawdata, 2450 + i*65, 2453 + i*65)
    data[[paste0("e.general.logging.overhead.", 2+i)]] <- substr(rawdata, 2454 + i*65, 2457 + i*65)
    data[[paste0("e.glp.", 2+i)]] <- substr(rawdata, 2458 + i*65, 2461 + i*65)
    data[[paste0("e.slash.disposal.", 2+i)]] <- substr(rawdata, 2462 + i*65, 2465 + i*65)
    data[[paste0("e.erosion.control.", 2+i)]] <- substr(rawdata, 2466 + i*65, 2469 + i*65)
    data[[paste0("e.snag.disposal.", 2+i)]] <- substr(rawdata, 2470 + i*65, 2473 + i*65)
    data[[paste0("e.miscellaneous", 2+i)]] <- substr(rawdata, 2474 + i*65, 2477 + i*65)
    data[[paste0("e.temp.roads", 2+i)]] <- substr(rawdata, 2478 + i*65, 2481 + i*65)
    data[[paste0("e.other.temp.development", 2+i)]] <- substr(rawdata, 2482 + i*65, 2485 + i*65)
  }
  print(paste0("Completed column ", 2485))
  
  write.csv(data, file = paste0("data/clean_data/usfs_", year, ".csv"), row.names = FALSE)
  
}
