## Load Data
#df_1982 <- read.csv("clean_data/usfs_82.csv")
#df_1983 <- read.csv("clean_data/usfs_83.csv")
#df_1984 <- read.csv("clean_data/usfs_84.csv")
#df_1985 <- read.csv("clean_data/usfs_85.csv")
#df_1986 <- read.csv("clean_data/usfs_86.csv")

df_1987 <- read.csv("data/clean_data/usfs_87.csv", colClasses = "character")
df_1988 <- read.csv("data/clean_data/usfs_88.csv", colClasses = "character")
df_1989 <- read.csv("data/clean_data/usfs_89.csv", colClasses = "character")
df_1990 <- read.csv("data/clean_data/usfs_90.csv", colClasses = "character")
data <- rbind(df_1987, df_1988, df_1989, df_1990)#,
#              df_1986, df_1985, df_1984, df_1983, df_1982)
rm(df_1987, df_1988, df_1989, df_1990)


## Select Subset
keep_if <- rep(T, dim(data)[1])

# Use only Northern Forests
keep_if[data$region != "01"] <- F

# Use only Kootenai and Idaho Panhandle
keep_if[!(data$forest %in% c("04", "14"))] <- F

# Use only Use Schuster & Niccolucci random assignment subsample
keep_if[data$forest == "14" & !(data$district %in% c("01","02","05"))] <- F

# Drop sales restricted to small businesses
keep_if[!(data$sba.set.aside == "N")] <- F
#keep_if[data$sba.set.aside %in% c("W", "X", "Y", "Z")] <- F

keep_if[!(data$method.of.sale %in% c("A", "S"))] <- F

keep_if[!(data$status == "1")] <- F

data <- data[keep_if, ] # 393 observations vs 378 reported by Athey et al

# Clean Firm Names
# maxwidth <- max(sapply(firm.id.list[, 2], nchar))
# NAs from as.numeric. Doesn't matter since we match on firm name. 
maxwidth <- 7
for(i in 1:12){
  data[[paste0("b.bidders.name.", i)]] <- trimws(data[[paste0("b.bidders.name.", i)]], "both")
  data[[paste0("b.identification.number.", i)]] <- as.numeric(trimws(data[[paste0("b.identification.number.", i)]], "both"))
  data[[paste0("b.identification.number.", i)]] <- formatC(data[[paste0("b.identification.number.", i)]], width = maxwidth, format = "d", flag = "0")
}

firm.id.list <- data.frame(cbind(c(data$b.bidders.name.1, data$b.bidders.name.2, data$b.bidders.name.3, data$b.bidders.name.4,
        data$b.bidders.name.5, data$b.bidders.name.6, data$b.bidders.name.7, data$b.bidders.name.8, 
        data$b.bidders.name.9, data$b.bidders.name.10, data$b.bidders.name.11, data$b.bidders.name.12),
      c(data$b.identification.number.1, data$b.identification.number.2, data$b.identification.number.3, 
        data$b.identification.number.4, data$b.identification.number.5, data$b.identification.number.6,
        data$b.identification.number.7, data$b.identification.number.8, data$b.identification.number.9,
        data$b.identification.number.10, data$b.identification.number.11, data$b.identification.number.12)))
firm.id.list <- firm.id.list[order(firm.id.list[, 1]) ,]
firm.id.list <- unique(firm.id.list)

# Export CSV for manual cleaning
write.csv(firm.id.list, file = "data/clean_firm_names/firm_id_list.csv", row.names = FALSE)

# Import Cleaned CSV
firm.id.standardized <- read.csv("data/clean_firm_names/manual_clean_names.csv")
firm.id.standardized <- cbind(firm.id.standardized, as.numeric(factor(firm.id.standardized[, 3])))

for (i in 1:12){
  data[[paste0("b.bidders.id.", i)]] <- firm.id.standardized[match(data[[paste0("b.bidders.name.", i)]], firm.id.standardized[, 1]), 5]
}

# Find total MBF
data$total.mbf <- 0
for(i in 1:14){
  species.mbf <- as.numeric(data[[paste0("d.volume.", i)]])
  species.mbf[is.na(species.mbf)] <- 0
  # 1 CCF -> 1.2 MBF
  species.mbf[data[[paste0("d.unit.", i)]] %in% c("4", "9")] <- species.mbf[data[[paste0("d.unit.", i)]] %in% c("4", "9")]*1.2 
  # 1 cord -> 0.5 MBF
  species.mbf[data[[paste0("d.unit.", i)]] %in% c("8")] <- species.mbf[data[[paste0("d.unit.", i)]] %in% c("8")]*0.5
  
  
  data$total.mbf <- data$total.mbf + species.mbf
  
}
hist(data$total.mbf)
mean(data$total.mbf[data$method.of.sale == "S"])
mean(data$total.mbf[data$method.of.sale == "A"])

# Build Adjacency Matrix - Open
data.use <- data[data$method.of.sale == "A", ]
adj.val <- matrix(0, dim(data.use)[1], max(firm.id.standardized[, 5], na.rm = T))
adj.price <- matrix(0, dim(data.use)[1], max(firm.id.standardized[, 5], na.rm = T))
adj.SBA <- matrix("", dim(data.use)[1], max(firm.id.standardized[, 5], na.rm = T))
for(i in 1:12){
  for(j in 1:(dim(data.use)[1])){
    bidder <- data.use[[paste0("b.bidders.id.", i)]][j]
    if (!is.na(bidder)){
      adj.val[j, bidder] <- as.numeric(data.use[[paste0("b.total.value.of.bid.", i)]][j])/100
      adj.price[j, bidder] <- as.numeric(data.use[[paste0("b.total.value.of.bid.", i)]][j])/(100*data.use$total.mbf[j])
      adj.SBA[j, bidder] <- data.use[[paste0("b.sba.class.", i)]][j]
    }
  }
}
hist(adj.price[adj.price != 0])
# Mean winning bid:
mean(as.numeric(data.use[[paste0("b.total.value.of.bid.", 1)]])/(100*data.use$total.mbf))
A.adj.val <- adj.val
A.adj.price <- adj.price
A.auct.list <- data.use[, 1:10]
A.adj.SBA <- adj.SBA
A.data <- data.use

# Build Adjacency Matrix - Sealed Bid
data.use <- data[data$method.of.sale == "S", ]
adj.val <- matrix(0, dim(data.use)[1], max(firm.id.standardized[, 5], na.rm = T))
adj.price <- matrix(0, dim(data.use)[1], max(firm.id.standardized[, 5], na.rm = T))
adj.SBA <- matrix("", dim(data.use)[1], max(firm.id.standardized[, 5], na.rm = T))
for(i in 1:12){
  for(j in 1:(dim(data.use)[1])){
    bidder <- data.use[[paste0("b.bidders.id.", i)]][j]
    if (!is.na(bidder)){
      adj.val[j, bidder] <- as.numeric(data.use[[paste0("b.total.value.of.bid.", i)]][j])/100
      if(is.na(adj.val[j, bidder])) stop("Bid value NA")
      adj.price[j, bidder] <- as.numeric(data.use[[paste0("b.total.value.of.bid.", i)]][j])/(100*data.use$total.mbf[j])
      if(is.na(adj.price[j, bidder])) stop("Bid price NA")
      adj.SBA[j, bidder] <- data.use[[paste0("b.sba.class.", i)]][j]
    }
  }
}
hist(adj.price[adj.price != 0])
# Mean winning bid:
mean(as.numeric(data.use[[paste0("b.total.value.of.bid.", 1)]])/(100*data.use$total.mbf))
S.adj.val <- adj.val
S.adj.price <- adj.price
S.auct.list <- data.use[, 1:10]
S.adj.SBA <- adj.SBA
S.data <- data.use


firm.type <- apply(rbind(S.adj.SBA, A.adj.SBA), 2, function(x) return(names(sort(-table(x[x!=""])))[1]))

firm.list <- unique(firm.id.standardized[, c(5,3)])
firm.list <- firm.list[order(firm.list[, 1]), ]
colnames(firm.list) <- c("firm.id", "firm.name")
firm.list <- cbind(firm.list, c(firm.type, "<NA>"))

save(data, file = "data/adj_mat/auction_characteristics.Rdata")
save(S.data, A.data, firm.type, file = "data/covariates/covariates.Rdata")

save(A.adj.val, A.adj.price, A.auct.list,
     S.adj.val, S.adj.price, S.auct.list,
     firm.list, file = "data/adj_mat/adj_mat.Rdata")
