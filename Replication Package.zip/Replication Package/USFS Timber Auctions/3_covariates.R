################################################################################
## USFS Auctions
################################################################################
# 
library(tidyverse)
library(matrixcalc)

## Load Data

load("data/adj_mat/adj_mat.Rdata")
load("data/covariates/covariates.Rdata")

set.seed(123)
S.use <- sample(1:148)[1:122]
A.use <- sample(1:245)[1:244]

data.use <- rbind(S.data[S.use, ], A.data[A.use, ])

n.treat <- 122
n.control <- 244
n.total <- n.treat+n.control

A.val <- t(A.adj.val[A.use, ])
S.val <- t(S.adj.val[S.use, ])
A.price <- t(A.adj.price[A.use, ])
S.price <- t(S.adj.price[S.use, ])

A.entry <- (A.val > 0)*1
S.entry <- (S.val > 0)*1

entry.tract <- t(cbind(S.entry, A.entry))

# Coentry
coentry.tract <- t(cbind(S.entry, A.entry))%*%cbind(S.entry, A.entry)

# Covariate Matrices

SBA.asym <- matrix(firm.list[1:224, 3], n.total, 224, byrow = TRUE) # firm type
SBA.asym.num <- price.tract*0
SBA.asym.num[SBA.asym == "S"] <- 1
SBA.asym.num[SBA.asym == "N"] <- 2
SBA.asym.num[SBA.asym == "L"] <- 3

data.use$location <- paste0(data.use$forest, data.use$district)
data.use$location.num <- as.numeric(factor(data.use$location))

location.asym <- matrix(data.use$location.num, n.total, 224, byrow = FALSE)
tractsize.asym <- matrix(ntile(data.use$total.mbf, 4), n.total, 224, byrow = FALSE)

# ------------------------------------------------------------------------------
# Treatment Effects
# ------------------------------------------------------------------------------

asym_testmats <- "entry"

set.seed(123)
for(i in 1:length(asym_testmats)){
  testmat <- get(paste0(asym_testmats[i], ".tract"))
  testmat.treat <- testmat[1:n.treat, ]
  testmat.control <- testmat[n.treat + 1:n.control, ]
  
  # ----------------------------------------------------------------------------
  # Tract Size x Firm Type
  # ----------------------------------------------------------------------------
  
  effect.table <- matrix(0, 0, 5)
  for(level in 1:4){
    for(f.level in 1:3){
      treat.l <- testmat.treat[tractsize.asym[1:n.treat, ] == level & SBA.asym.num[1:n.treat, ] == f.level  ]
      control.l <- testmat.control[tractsize.asym[n.treat+1:n.control, ] == level & SBA.asym.num[n.treat+1:n.control, ]  == f.level  ]
      
      if(length(treat.l) == 0 || length(control.l) == 0){
        est <- NA
      } else {
        est <- mean(treat.l) - mean(control.l)
      }
      
      effect.table <- rbind(effect.table, c(level, f.level, est, length(treat.l), length(control.l)))
      
    }
  }
  
  write.csv(effect.table, file = paste0("data/covariates/tractfirm_", asym_testmats[i], "_table.csv"), row.names = FALSE)
  
  # ----------------------------------------------------------------------------
  # Location x Firm Type
  # ----------------------------------------------------------------------------
  
  effect.table <- matrix(0, 0, 5)
  for(level in 1:10){
    for(f.level in 1:3){
      
      treat.l <- testmat.treat[location.asym[1:n.treat, ] == level & SBA.asym.num[1:n.treat, ] == f.level  ]
      control.l <- testmat.control[location.asym[n.treat+1:n.control, ] == level & SBA.asym.num[n.treat+1:n.control, ]  == f.level  ]
      
      if(length(treat.l) == 0 || length(control.l) == 0){
        est <- NA
      } else {
        est <- mean(treat.l) - mean(control.l)
      }
      
      effect.table <- rbind(effect.table, c(level, f.level, est, length(treat.l), length(control.l)))
      
    }
  }
  
  write.csv(effect.table, file = paste0("data/covariates/tlocfsize_", asym_testmats[i], "_table.csv"), row.names = FALSE)
  
  
}

# ------------------------------------------------------------------------------
# Overlays
# ------------------------------------------------------------------------------

for(i in 1:length(asym_testmats)){
  datatable <- read.csv(paste0("data/covariates/tlocfsize_", asym_testmats[i], "_table.csv"))
  out <- c()
  for(j in 1:dim(datatable)[1]){
    if(!is.na(datatable[j,2])){
      out <- c(out, rep(datatable[j,3], datatable[j,4]))
    }
  }
  # Plot Histogram of Treatment Effects
  effect.mat <- data.frame(out)
  colnames(effect.mat) <- "net"
  save(effect.mat, file = paste0("data/overlays/tlocfsize_", asym_testmats[i], ".Rdata")) # output file for overlays
  
}




