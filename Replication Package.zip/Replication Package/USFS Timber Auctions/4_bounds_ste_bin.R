## =============================================================================
## USFS Auctions                    
## =============================================================================

library(tidyverse)
library(MatrixHTE)

## Load Data

load("data/adj_mat/adj_mat.Rdata")

firm.scale <- 1

set.seed(123)
S.use <- sample(1:148)[1:122]
A.use <- sample(1:245)[1:244]

A.val <- t(A.adj.val[A.use, ])
S.val <- t(S.adj.val[S.use, ])
A.price <- t(A.adj.price[A.use, ])
S.price <- t(S.adj.price[S.use, ])

A.entry <- (A.val > 0)*1
S.entry <- (S.val > 0)*1

A.coentry.tract <- t(A.entry)%*%A.entry
S.coentry.tract <- t(S.entry)%*%S.entry

firm.list[, 4] <- ifelse(firm.list[,3] == "N", "S", "L") # Millers are S or L, Loggers are N
firm.list[, 3] <- firm.list[, 4]
firm.list <- firm.list[1:224, ]

# ATEs
mean(S.entry) - mean(A.entry)
mean(S.entry[firm.list[1:224,3] == "L", ]) - mean(A.entry[firm.list[1:224,3] == "L", ])
mean(S.entry[firm.list[1:224,3] == "S", ]) - mean(A.entry[firm.list[1:224,3] == "S", ])

# ------------------------------------------------------------------------------
# Bounds for Entry
# ------------------------------------------------------------------------------

# Levels
i.val <- c(1,0)
j.val <- c(1,0)
result_overall <- data.frame()
select <- list("all" = c(1:224), "small" = firm.list$firm.id[firm.list[, 3] == "S"], "large" = firm.list$firm.id[firm.list[, 3] == "L"])
for(k in c("all", "small", "large")){
  count <- 0
  result <- matrix(0, length(i.val)*length(j.val), 2+2)
  for(i in i.val){
    for(j in j.val){
      
      treat.use <- (S.entry[select[[k]], ] == i)*1
      control.use <- (A.entry[select[[k]], ] == j)*1
      treat.use.bin <- S.entry[select[[k]], ]
      control.use.bin <- A.entry[select[[k]], ]
      
      result_iter <- matrix(0, 1, 4) #hc, no hc, svt hc, svt
      
      result_iter[, 1] <- i
      result_iter[, 2] <- j
      bounds_svt_hc <- dpo_bounds_svt_bin(treat.use.bin, control.use.bin, i, j, hc = TRUE)
      result_iter[, 3:4] <- bounds_svt_hc$bounds  

      result[count+1, ] <- result_iter
      count <- count + 1
      
    }
  }
  result <- data.frame(k, result)
  result_overall <- rbind(result_overall, result)
}

# Save Output
colnames(result_overall) <- c("sample", "y1", "y0", "lower", "upper")

write.csv(result_overall, file = paste0("results/entry/usfs_bounds_bin.csv"), row.names = F)


# ------------------------------------------------------------------------------
# Spectral Treatment Effects on Entry
# ------------------------------------------------------------------------------
library(matrixcalc)
source("application_functions.R")

effects <- ste(svt.smooth(S.entry, mean(S.entry), 0.01), svt.smooth(A.entry, mean(A.entry), 0.01), hc= TRUE)

# Compare distribution of treatment effects
load("data/overlays/tlocfsize_entry.Rdata")
ste <- data.frame("net" = effects$stt)
cate <- effect.mat

cate$var <- "CATT"
ste$var <- "STT"
effect.mat <- rbind(cate, ste)
ggplot(effect.mat, aes(x=net, fill = var)) +
  xlab(expr(paste("Effect")))+ylab("Density")+
  ggtitle(expr(paste("Distribution of Treatment Effects")))+
  geom_density(alpha = 0.6, adjust = 2)+
  scale_fill_manual(values=c("#56B4E9", "#F37735"))+
  labs(fill="") +
  #geom_histogram(alpha = 0.8, position = "identity", bins=100)+
  theme_minimal() + xlim(-0.2,0.1)+
  theme(plot.title = element_text(hjust = 1))
ggsave(paste0("results/entry/entry_ste_overlay_svt.png"), width = 15, height = 8, units = "cm")
