# convert frequency table to histogram
freq2hist <- function(val, count){
  # val <- combined$lev.tot; count <- combined$t.count
  out <- c()
  for(i in 1:length(val)){
    if(!is.na(val[i])){
      out <- c(out, rep(val[i], count[i]))
    }
  }
  print(paste0(sum(count[is.na(val)], na.rm = T), " out of ", sum(count, na.rm = T),
               " (", round(sum(count[is.na(val)], na.rm = T)/sum(count, na.rm = T), digits = 5), ")", " missing."))
  
  return(out)
}

joint_blowup <- function(Treat.Mat, Control.Mat){
  # Treat.Mat <- treat.lev; Control.Mat <- 1-control.lev
  # Treat.Mat <- S.price; Control.Mat <- A.price
  treat.n <- dim(Treat.Mat)
  control.n <- dim(Control.Mat)
  
  # Compute scaling factors and scale the matrices
  treat.scale.1 <- pracma::Lcm(treat.n[1], control.n[1])/treat.n[1]
  control.scale.1 <- pracma::Lcm(treat.n[1], control.n[1])/control.n[1]
  treat.scale.2 <- pracma::Lcm(treat.n[2], control.n[2])/treat.n[2]
  control.scale.2 <- pracma::Lcm(treat.n[2], control.n[2])/control.n[2]
  
  treat.out <- kronecker(Treat.Mat, matrix(1,treat.scale.1,treat.scale.2))
  control.out <- kronecker(Control.Mat, matrix(1,control.scale.1,control.scale.2))
  
  return(list(treat.out, control.out))
  
}

vector_frechet <- function(Treat.Mat, Control.Mat){
  
  blowup <- joint_blowup(Treat.Mat, Control.Mat)
  Treat.Mat <- blowup[[1]]
  Control.Mat <- blowup[[2]]
  
  Treat.ev <- svd(Treat.Mat)$d
  Control.ev <- svd(Control.Mat)$d 
  
  n <- dim(Treat.Mat)[1] # only for symmetric matrices
  m <- dim(Treat.Mat)[2]
  
  VF_lower <- max(sum(Treat.ev^2) + sum(Control.ev^2) - n*m, 0)/(n*m)
  VF_upper <- min(sum(Treat.ev^2), sum(Control.ev^2))/(n*m)
  
  return(c(VF_lower, VF_upper))
}

# scaled_colorRamp <- function(E_weight, scale = 0.5){
#   
#   c_scale.neg <- colorRamp(c('white', 'red'))
#   c_scale.pos <- colorRamp(c('white', 'blue'))
#   
#   E_weight[E_weight > 1] <- 1
#   E_weight[E_weight < -1] <- -1
#   
#   E_weight <- sign(E_weight)*abs(E_weight)^scale
#   
#   color <- matrix(0, length(E_weight), 3)
#   color[E_weight < 0, ] <- c_scale.neg(-E_weight[E_weight < 0])
#   color[E_weight >= 0, ] <- c_scale.pos(E_weight[E_weight > 0])
#   
#   color.hex <- apply(color, 1, function(x) rgb(x[1]/255,x[2]/255,x[3]/255))
#   
#   return(color.hex)
#   
# }