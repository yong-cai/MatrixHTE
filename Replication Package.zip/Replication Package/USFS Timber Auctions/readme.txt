### Replication Instructions ###

1) The replication package contains USFS Auction Data downloaded from Philip Haile's website at <https://www.dropbox.com/sh/r9v8wbmr8omoyav/AAD3P3wX1MriDQ9VGVTcexF3a?dl=0>. It is contained in <data/Haile Data>

2) Run <1_clean_usfs.R> to clean the data

3) Run <2_build_adjmat - sn_subsample.R> to build adjacency matrices for auctions corresponding to the Schuster and Niccolucci subsample (1994). 

4) Run <3_covariates.R> to compute CATT for comparison with the STTs later

5) Run <4_bounds_ste_bin.R> to compute bounds in Table 2 and Figure 4. 